import express from 'express';
import { Queue } from 'bullmq';
import IORedis from 'ioredis';
import { metricsApp } from './metrics';

const app = express();
const port = 3003;
const redis = new IORedis(process.env.REDIS_URL || 'redis://localhost:6379');
const imageQueue = new Queue('image-generation', { connection: redis });

app.use(express.json());

// Endpoint pour générer une image
app.post('/image/generate', async (req, res) => {
  const { prompt, options } = req.body;
  
  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  const job = await imageQueue.add('generate', { prompt, options });
  
  res.status(202).json({ jobId: job.id, status: 'queued' });
});

// Endpoint pour vérifier le statut
app.get('/image/status/:jobId', async (req, res) => {
  const { jobId } = req.params;
  const job = await imageQueue.getJob(jobId);
  
  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }

  const state = await job.getState();
  const result = job.returnvalue;

  res.json({
    id: job.id,
    status: state,
    url: result?.url || null
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'design' });
});

// Monter les métriques sur /metrics
app.use(metricsApp);

app.listen(port, () => {
  console.log(`Design service running on port ${port}`);
});
