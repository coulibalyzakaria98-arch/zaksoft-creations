import express from 'express';
import { Queue } from 'bullmq';
import IORedis from 'ioredis';
import { metricsApp } from './metrics';

const app = express();
const port = 3004;
const redis = new IORedis(process.env.REDIS_URL || 'redis://localhost:6379');
const webGenQueue = new Queue('web-generation', { connection: redis });

app.use(express.json());

// Endpoint to trigger web generation
app.post('/web/generate', async (req, res) => {
  const { prompt, siteConfig } = req.body;
  
  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  const job = await webGenQueue.add('generate', { prompt, siteConfig });
  
  res.status(202).json({ jobId: job.id, status: 'queued' });
});

// Endpoint to check status
app.get('/web/status/:jobId', async (req, res) => {
  const { jobId } = req.params;
  const job = await webGenQueue.getJob(jobId);
  
  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }

  const state = await job.getState();
  const result = job.returnvalue;

  res.json({
    id: job.id,
    status: state,
    url: result?.url || null
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'web-gen' });
});

// Mount metrics
app.use(metricsApp);

app.listen(port, () => {
  console.log(`Web Gen service running on port ${port}`);
});
