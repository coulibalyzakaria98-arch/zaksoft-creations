import { Worker } from 'bullmq';
import axios from 'axios';
import IORedis from 'ioredis';

const redis = new IORedis(process.env.REDIS_URL || 'redis://localhost:6379');

interface SVDBridgeConfig {
  url: string; // http://svd-local:7860
}

class SVDWorker {
  private config: SVDBridgeConfig;
  
  constructor(config: SVDBridgeConfig) {
    this.config = config;
  }
  
  async generateVideoFromImage(imageUrl: string, options?: {
    fps?: number;
    frames?: number;
    seed?: number;
  }): Promise<string> {
    const response = await axios.post(`${this.config.url}/generate`, {
      image_url: imageUrl,
      fps: options?.fps || 6,
      frames: options?.frames || 25,
      seed: options?.seed
    });
    
    const { job_id } = response.data;
    
    // Polling jusqu'à complétion
    let videoUrl = null;
    for (let i = 0; i < 60; i++) {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const statusRes = await axios.get(`${this.config.url}/status/${job_id}`);
      if (statusRes.data.status === 'completed') {
        videoUrl = `${this.config.url}${statusRes.data.video_url}`;
        break;
      }
    }
    
    if (!videoUrl) throw new Error('SVD Generation timeout');
    return videoUrl;
  }
}

// Worker BullMQ
export const svdBridgeWorker = new Worker(
  'svd-generation',
  async (job) => {
    const { imageUrl, options } = job.data;
    const svdUrl = process.env.SVD_BRIDGE_URL || 'http://localhost:7860';
    const worker = new SVDWorker({ url: svdUrl });
    
    const videoUrl = await worker.generateVideoFromImage(imageUrl, options);
    
    // Télécharger et stocker dans S3 (mock implementation for now)
    const videoBuffer = await axios.get(videoUrl, { responseType: 'arraybuffer' });
    const s3Key = `videos/${job.id}.mp4`;
    // await uploadToS3(s3Key, videoBuffer.data);
    
    console.log(`Uploaded video to S3: ${s3Key}`);
    
    return { url: `https://storage.zaksoft.com/${s3Key}` };
  },
  { connection: redis }
);
