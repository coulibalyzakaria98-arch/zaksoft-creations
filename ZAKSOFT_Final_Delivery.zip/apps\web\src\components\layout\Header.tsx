// apps/web/src/components/layout/Header.tsx
'use client';

import { useAuth } from '@/hooks/useAuth';
import { LogoutButton } from '../auth/LogoutButton'; // Import the new component
import { Sparkles } from 'lucide-react'; // For the logo

export function Header() {
  const { user, isLoading } = useAuth();

  // Show loading spinner or minimal header while auth state is being determined
  if (isLoading) {
    return (
      <header className="bg-white border-b px-6 py-3 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-indigo-600" />
          <span className="text-lg font-bold text-indigo-600">ZAKSOFT</span>
        </div>
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </header>
    );
  }

  return (
    <header className="bg-white border-b px-6 py-3 flex justify-between items-center">
      <div>
        <h2 className="text-lg font-semibold text-gray-800">Bienvenue, {user?.email?.split('@')[0]}</h2>
        <p className="text-sm text-gray-500">
          Plan {user?.tier === 'free' ? 'Gratuit' : user?.tier === 'basic' ? 'Basique' : 'Pro'}
        </p>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="bg-indigo-100 px-3 py-1 rounded-full">
          <span className="text-sm font-medium text-indigo-700">{user?.credits ?? 0} crédits</span>
        </div>
        
        <LogoutButton /> {/* Use the LogoutButton component */}
      </div>
    </header>
  );
}
