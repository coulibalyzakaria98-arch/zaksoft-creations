import express from 'express';
import { Queue } from 'bullmq';
import IORedis from 'ioredis';
import { PrismaClient } from '@prisma/client';
import cors from 'cors';
import { templateManager } from './services/templateManager';
import { searchEngine } from './services/searchEngine';

const app = express();
const prisma = new PrismaClient();
const redis = new IORedis(process.env.REDIS_URL || 'redis://localhost:6379');
const importQueue = new Queue('template-import', { connection: redis });

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Mock authenticate middleware for now
const authenticate = (req: any, res: any, next: any) => {
  req.user = { id: req.headers['x-user-id'] || 'user_1' }; // Simulation
  next();
};

app.use(authenticate);

// ============ ENDPOINTS TEMPLATES ============

app.post('/templates', async (req: any, res) => {
  const { name, description, type, config, thumbnail, isPublic = true, price = 0 } = req.body;
  const userId = req.user.id;
  
  try {
    const template = await templateManager.createTemplate({
      name,
      description,
      type,
      config,
      thumbnail,
      isPublic,
      price,
      authorId: userId
    });
    
    res.json(template);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/templates', async (req, res) => {
  const { page = 1, limit = 20, type, sort = 'popular', search, category } = req.query;
  
  try {
    const templates = await searchEngine.search({
      page: Number(page),
      limit: Number(limit),
      type: type as string,
      sort: sort as string,
      search: search as string,
      category: category as string
    });
    
    res.json(templates);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/templates/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const template = await templateManager.getTemplate(id);
    if (!template) return res.status(404).json({ error: 'Template not found' });
    res.json(template);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/templates/:id/import', async (req: any, res) => {
  const { id } = req.params;
  const userId = req.user.id;
  
  try {
    const job = await importQueue.add('import', { templateId: id, userId });
    res.json({ jobId: job.id, status: 'pending' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/categories', async (req, res) => {
  try {
    const categories = await prisma.category.findMany({
      include: { _count: { select: { templates: true } } }
    });
    res.json(categories);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.MARKETPLACE_SERVICE_PORT || 3006;
app.listen(PORT, () => console.log(`Marketplace service on ${PORT}`));
