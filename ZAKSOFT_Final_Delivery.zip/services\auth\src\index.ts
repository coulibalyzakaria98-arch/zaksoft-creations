import express from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { PrismaClient } from '@prisma/client';

const app = express();
const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET!;

app.use(express.json());

// Register endpoint
app.post('/auth/register', async (req, res) => {
  const { email, password } = req.body;
  
  const hashedPassword = await bcrypt.hash(password, 10);
  
  const user = await prisma.user.create({
    data: { email, passwordHash: hashedPassword, tier: 'free', credits: 10 }
  });
  
  const token = jwt.sign({ userId: user.id, tier: user.tier }, JWT_SECRET);
  res.json({ token, user: { id: user.id, email: user.email, tier: user.tier, credits: user.credits } });
});

// Login endpoint
app.post('/auth/login', async (req, res) => {
  const { email, password } = req.body;
  
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return res.status(401).json({ error: 'Invalid credentials' });
  
  const token = jwt.sign({ userId: user.id, tier: user.tier }, JWT_SECRET);
  res.json({ token, user: { id: user.id, email: user.email, tier: user.tier, credits: user.credits } });
});

app.listen(3001, () => console.log('Auth service running on 3001'));
