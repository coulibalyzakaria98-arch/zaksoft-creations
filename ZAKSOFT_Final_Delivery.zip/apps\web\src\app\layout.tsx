// apps/web/src/app/layout.tsx
'use client'; // This layout needs to be client-side for AuthProvider and AuthGuard

import { AuthProvider } from '@/hooks/useAuth';
import { AuthGuard } from '@/components/auth/AuthGuard';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import './globals.css';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <AuthProvider>
          <div className="flex h-screen bg-gray-50">
            <Sidebar />
            <div className="flex-1 flex flex-col overflow-hidden">
              <Header />
              <main className="flex-1 overflow-y-auto p-4">
                <AuthGuard>{children}</AuthGuard>
              </main>
            </div>
          </div>
        </AuthProvider>
      </body>
    </html>
  );
}
