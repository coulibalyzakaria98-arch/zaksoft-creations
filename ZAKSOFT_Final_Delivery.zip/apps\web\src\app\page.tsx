'use client';

import { useAuth } from '@/hooks/useAuth';
import { 
  Palette, 
  Video, 
  Globe, 
  Zap, 
  Clock, 
  CreditCard 
} from 'lucide-react';
import Link from 'next/link';

export default function DashboardPage() {
  const { user } = useAuth();

  const stats = [
    { name: 'Crédits Restants', value: user?.credits ?? 0, icon: Zap, color: 'text-amber-600', bg: 'bg-amber-100' },
    { name: 'Générations ce mois', value: '24', icon: Clock, color: 'text-blue-600', bg: 'bg-blue-100' },
    { name: 'Plan Actuel', value: user?.tier?.toUpperCase() || 'FREE', icon: CreditCard, color: 'text-indigo-600', bg: 'bg-indigo-100' },
  ];

  const services = [
    { 
      name: 'Design Graphique', 
      description: 'Créez des visuels époustouflants avec Stable Diffusion XL.',
      href: '/design/generate',
      icon: Palette,
      color: 'bg-purple-500'
    },
    { 
      name: 'Génération Vidéo', 
      description: 'Transformez vos idées en vidéos cinématographiques.',
      href: '/video/generate',
      icon: Video,
      color: 'bg-blue-500'
    },
    { 
      name: 'Génération Web', 
      description: 'Générez des sites web complets en quelques secondes.',
      href: '/web-gen/generate',
      icon: Globe,
      color: 'bg-emerald-500'
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Tableau de bord</h1>
        <p className="text-gray-500">Bienvenue sur ZAKSOFT Créations. Que voulez-vous créer aujourd'hui ?</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat) => (
          <div key={stat.name} className="bg-white p-6 rounded-xl shadow-sm border flex items-center space-x-4">
            <div className={`${stat.bg} p-3 rounded-lg`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">{stat.name}</p>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Services Quick Access */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Nos Services IA</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {services.map((service) => (
            <Link 
              key={service.name} 
              href={service.href}
              className="group bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow"
            >
              <div className={`${service.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <service.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-1">{service.name}</h3>
              <p className="text-sm text-gray-500">{service.description}</p>
              <div className="mt-4 flex items-center text-indigo-600 font-medium text-sm">
                Essayer maintenant
                <svg className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="9 5l7 7-7 7" />
                </svg>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent Activity Placeholder */}
      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="px-6 py-4 border-b">
          <h2 className="font-semibold text-gray-900">Activité Récente</h2>
        </div>
        <div className="p-6 text-center text-gray-500 italic">
          Vos dernières créations apparaîtront ici.
        </div>
      </div>
    </div>
  );
}
