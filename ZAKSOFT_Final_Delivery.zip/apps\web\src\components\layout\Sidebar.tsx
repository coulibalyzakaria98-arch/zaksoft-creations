'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  LayoutDashboard, 
  Palette, 
  Video, 
  Globe, 
  Store, 
  Users, 
  Settings,
  CreditCard
} from 'lucide-react';
import { cn } from '@/lib/utils'; // I'll need to check if this exists or create it

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Design Graphique', href: '/design/generate', icon: Palette },
  { name: 'Génération Vidéo', href: '/video/generate', icon: Video },
  { name: 'Génération Web', href: '/web-gen/generate', icon: Globe },
  { name: 'Marketplace', href: '/marketplace', icon: Store },
  { name: 'Équipe', href: '/teams', icon: Users },
  { name: 'Facturation', href: '/billing', icon: CreditCard },
  { name: 'Paramètres', href: '/settings', icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <div className="flex flex-col w-64 bg-white border-r">
      <div className="flex items-center justify-center h-16 border-b">
        <span className="text-2xl font-bold text-indigo-600">ZAKSOFT</span>
      </div>
      <nav className="flex-1 overflow-y-auto py-4">
        {navigation.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                'flex items-center px-6 py-3 text-sm font-medium transition-colors',
                isActive 
                  ? 'text-indigo-600 bg-indigo-50 border-r-4 border-indigo-600' 
                  : 'text-gray-600 hover:text-indigo-600 hover:bg-gray-50'
              )}
            >
              <item.icon className="w-5 h-5 mr-3" />
              {item.name}
            </Link>
          );
        })}
      </nav>
      <div className="p-4 border-t">
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg p-4 text-white">
          <p className="text-xs font-semibold uppercase tracking-wider mb-1">Passer à la vitesse supérieure</p>
          <p className="text-sm mb-3">Obtenez plus de crédits et de fonctionnalités.</p>
          <button className="w-full bg-white text-indigo-600 text-xs font-bold py-2 rounded shadow-sm hover:bg-indigo-50 transition-colors">
            DEVENIR PRO
          </button>
        </div>
      </div>
    </div>
  );
}
