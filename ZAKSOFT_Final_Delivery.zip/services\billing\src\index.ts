import express from 'express';
import Stripe from 'stripe';
import { PrismaClient } from '@prisma/client';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const prisma = new PrismaClient();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16' as any
});

app.use(cors());

// Configuration des produits
const PRODUCTS = {
  free: { credits: 10, price: 0, priceId: null },
  basic: { credits: 100, price: 990, priceId: process.env.STRIPE_BASIC_PRICE_ID },
  pro: { credits: 500, price: 2990, priceId: process.env.STRIPE_PRO_PRICE_ID },
  enterprise: { credits: 5000, price: 9990, priceId: process.env.STRIPE_ENTERPRISE_PRICE_ID }
};

// Créer une session de checkout
app.post('/billing/create-checkout-session', express.json(), async (req, res) => {
  const { userId, priceId, successUrl, cancelUrl } = req.body;
  
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      mode: 'subscription',
      client_reference_id: userId,
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: { userId }
    });
    
    res.json({ sessionId: session.id, url: session.url });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Créer un portail client
app.post('/billing/create-portal-session', express.json(), async (req, res) => {
  const { userId } = req.body;
  
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { stripeCustomerId: true }
    });
    
    if (!user?.stripeCustomerId) {
      return res.status(400).json({ error: "No Stripe customer found for this user" });
    }

    const session = await stripe.billingPortal.sessions.create({
      customer: user.stripeCustomerId,
      return_url: `${process.env.FRONTEND_URL}/billing`
    });
    
    res.json({ url: session.url });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Webhook Stripe
app.post('/billing/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'] as string;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;
  
  let event: Stripe.Event;
  
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err: any) {
    console.error(`Webhook Error: ${err.message}`);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  
  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.client_reference_id;
        const lineItems = await stripe.checkout.sessions.listLineItems(session.id);
        const priceId = lineItems.data[0]?.price?.id;
        
        let tier: 'free' | 'basic' | 'pro' | 'enterprise' = 'free';
        let credits = 0;
        
        if (priceId === PRODUCTS.basic.priceId) {
          tier = 'basic';
          credits = PRODUCTS.basic.credits;
        } else if (priceId === PRODUCTS.pro.priceId) {
          tier = 'pro';
          credits = PRODUCTS.pro.credits;
        } else if (priceId === PRODUCTS.enterprise.priceId) {
          tier = 'enterprise';
          credits = PRODUCTS.enterprise.credits;
        }
        
        if (userId) {
          await prisma.user.update({
            where: { id: userId },
            data: {
              tier,
              credits: { increment: credits },
              stripeCustomerId: session.customer as string,
              stripeSubscriptionId: session.subscription as string
            }
          });
          
          await prisma.creditTransaction.create({
            data: {
              userId: userId,
              amount: credits,
              operation: 'purchase',
              metadata: { sessionId: session.id } as any
            }
          });
        }
        break;
      }
      
      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as Stripe.Invoice;
        const customerId = invoice.customer as string;
        
        const user = await prisma.user.findFirst({
          where: { stripeCustomerId: customerId }
        });
        
        if (user) {
          const monthlyCredits = user.tier === 'basic' ? 100 : user.tier === 'pro' ? 500 : 5000;
          await prisma.user.update({
            where: { id: user.id },
            data: { credits: { increment: monthlyCredits } }
          });
          
          await prisma.creditTransaction.create({
            data: {
              userId: user.id,
              amount: monthlyCredits,
              operation: 'monthly_renewal',
              metadata: { invoiceId: invoice.id } as any
            }
          });
        }
        break;
      }
      
      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        const subCustomerId = subscription.customer as string;
        
        await prisma.user.updateMany({
          where: { stripeCustomerId: subCustomerId },
          data: { tier: 'free' }
        });
        break;
      }
    }
  } catch (error) {
    console.error('Error processing webhook event:', error);
    return res.status(500).json({ error: 'Webhook processing failed' });
  }
  
  res.json({ received: true });
});

const PORT = process.env.BILLING_SERVICE_PORT || 3005;
app.listen(PORT, () => console.log(`Billing service on ${PORT}`));
